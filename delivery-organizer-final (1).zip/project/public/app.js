/**
 * Delivery Organizer - Frontend Application
 */

(function() {
    'use strict';

    // DOM Elements
    const elements = {
        uploadZone: document.getElementById('uploadZone'),
        fileInput: document.getElementById('fileInput'),
        fileInfo: document.getElementById('fileInfo'),
        fileName: document.getElementById('fileName'),
        fileSize: document.getElementById('fileSize'),
        removeBtn: document.getElementById('removeBtn'),
        uploadSection: document.getElementById('uploadSection'),
        processSection: document.getElementById('processSection'),
        processBtn: document.getElementById('processBtn'),
        statusSection: document.getElementById('statusSection'),
        statusCard: document.getElementById('statusCard'),
        statusTitle: document.getElementById('statusTitle'),
        statusMessage: document.getElementById('statusMessage'),
        resultSection: document.getElementById('resultSection'),
        resultCard: document.getElementById('resultCard'),
        statsGrid: document.getElementById('statsGrid'),
        downloadBtn: document.getElementById('downloadBtn'),
        errorSection: document.getElementById('errorSection'),
        errorMessage: document.getElementById('errorMessage')
    };

    // State
    let state = {
        uploadedFile: null,
        uploadedFilePath: null,
        processedResult: null
    };

    // API Base URL
    const API_BASE = window.location.origin;

    /**
     * Initialize the application
     */
    function init() {
        setupEventListeners();
        updateUI();
    }

    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Upload zone click
        elements.uploadZone.addEventListener('click', () => {
            elements.fileInput.click();
        });

        // File input change
        elements.fileInput.addEventListener('change', handleFileSelect);

        // Drag and drop
        elements.uploadZone.addEventListener('dragover', handleDragOver);
        elements.uploadZone.addEventListener('dragleave', handleDragLeave);
        elements.uploadZone.addEventListener('drop', handleDrop);

        // Remove button
        elements.removeBtn.addEventListener('click', handleRemoveFile);

        // Process button
        elements.processBtn.addEventListener('click', handleProcess);

        // Download button
        elements.downloadBtn.addEventListener('click', handleDownload);
    }

    /**
     * Handle file selection
     */
    async function handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            await uploadFile(file);
        }
    }

    /**
     * Handle drag over
     */
    function handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        elements.uploadZone.classList.add('drag-over');
    }

    /**
     * Handle drag leave
     */
    function handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        elements.uploadZone.classList.remove('drag-over');
    }

    /**
     * Handle file drop
     */
    async function handleDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        elements.uploadZone.classList.remove('drag-over');

        const files = e.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            if (file.type === 'application/pdf') {
                await uploadFile(file);
            } else {
                showError('يرجى اختيار ملف PDF فقط');
            }
        }
    }

    /**
     * Upload file to server
     */
    async function uploadFile(file) {
        try {
            const formData = new FormData();
            formData.append('pdf', file);

            showStatus('جاري الرفع...', 'يرجى الانتظار');

            const response = await fetch(`${API_BASE}/api/upload`, {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                state.uploadedFile = file;
                state.uploadedFilePath = data.filePath;

                // Update UI
                elements.fileName.textContent = file.name;
                elements.fileSize.textContent = formatFileSize(file.size);
                elements.uploadZone.style.display = 'none';
                elements.fileInfo.style.display = 'flex';
                elements.processSection.style.display = 'flex';

                hideStatus();
            } else {
                showError(data.error || 'فشل رفع الملف');
            }
        } catch (error) {
            showError('فشل الاتصال بالخادم');
            console.error('Upload error:', error);
        }
    }

    /**
     * Handle remove file
     */
    function handleRemoveFile() {
        state.uploadedFile = null;
        state.uploadedFilePath = null;
        state.processedResult = null;

        elements.fileInput.value = '';
        elements.uploadZone.style.display = 'flex';
        elements.fileInfo.style.display = 'none';
        elements.processSection.style.display = 'none';
        elements.resultSection.style.display = 'none';
        elements.errorSection.style.display = 'none';
    }

    /**
     * Handle process button click
     */
    async function handleProcess() {
        if (!state.uploadedFilePath) {
            showError('يرجى اختيار ملف أولاً');
            return;
        }

        try {
            elements.processBtn.disabled = true;
            showStatus('جاري المعالجة...', 'استخراج البيانات من ملف PDF');

            const response = await fetch(`${API_BASE}/api/process`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    filePath: state.uploadedFilePath
                })
            });

            const data = await response.json();

            if (data.success) {
                state.processedResult = data;

                hideStatus();
                showResult(data.stats);
            } else {
                hideStatus();
                showError(data.details || data.error || 'فشلت عملية المعالجة');
            }
        } catch (error) {
            hideStatus();
            showError('فشل الاتصال بالخادم');
            console.error('Process error:', error);
        } finally {
            elements.processBtn.disabled = false;
        }
    }

    /**
     * Handle download button click
     */
    async function handleDownload() {
        if (!state.processedResult || !state.processedResult.outputFileName) {
            showError('لا يوجد ملف للتحميل');
            return;
        }

        try {
            const link = document.createElement('a');
            link.href = `${API_BASE}/api/download/${state.processedResult.outputFileName}`;
            link.download = state.processedResult.outputFileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            showError('فشل تحميل الملف');
            console.error('Download error:', error);
        }
    }

    /**
     * Show status indicator
     */
    function showStatus(title, message) {
        elements.statusTitle.textContent = title;
        elements.statusMessage.textContent = message;
        elements.statusSection.style.display = 'flex';
        elements.resultSection.style.display = 'none';
        elements.errorSection.style.display = 'none';
    }

    /**
     * Hide status indicator
     */
    function hideStatus() {
        elements.statusSection.style.display = 'none';
    }

    /**
     * Show result
     */
    function showResult(stats) {
        elements.statsGrid.innerHTML = `
            <div class="stat-item">
                <span class="stat-value">${stats.stores || 0}</span>
                <span class="stat-label">عدد المتاجر</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.inputRows || 0}</span>
                <span class="stat-label">الصفوف المصدرية</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.outputRows || 0}</span>
                <span class="stat-label">صفوف الإخراج</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.totalPages || 0}</span>
                <span class="stat-label">صفحات PDF</span>
            </div>
        `;

        elements.resultSection.style.display = 'flex';
        elements.errorSection.style.display = 'none';
    }

    /**
     * Show error
     */
    function showError(message) {
        elements.errorMessage.textContent = message;
        elements.errorSection.style.display = 'flex';
        elements.resultSection.style.display = 'none';
    }

    /**
     * Update UI based on state
     */
    function updateUI() {
        // Reset to initial state
        elements.uploadZone.style.display = 'flex';
        elements.fileInfo.style.display = 'none';
        elements.processSection.style.display = 'none';
        elements.statusSection.style.display = 'none';
        elements.resultSection.style.display = 'none';
        elements.errorSection.style.display = 'none';
    }

    /**
     * Format file size
     */
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
